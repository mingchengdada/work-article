package com.mc.commonproject.test;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 项目名称:   pinkstone
 * 包:        com.mc.commonproject.test
 * 类名称:     Test
 * 类描述:     类功能描述
 * 创建人:     mc
 * 创建时间:   2019/4/15 14:09
 */
@RestController
public class Test {
    @Value("${name.age}")
    private String age;
    @GetMapping(value = "/test")
    public String test() {
        return age;
    }

}
