package com.mc.eurekaserver.test;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 项目名称:   pinkstone
 * 包:        com.mc.eurekaserver.test
 * 类名称:     TestController
 * 类描述:     类功能描述
 * 创建人:     mc
 * 创建时间:   2019/4/11 23:49
 */
@RestController
public class TestController {
    @Value("${name.age}")
    private String name;
    @RequestMapping("/test")
    public String test() {
        return name;
    }
}
